package com.tns_b83;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlacementApplicationTests {

	@Test
	void contextLoads() {
	}

}
