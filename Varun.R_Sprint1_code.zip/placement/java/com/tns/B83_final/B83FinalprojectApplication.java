package com.tns.B83_final;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class B83FinalprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(B83FinalprojectApplication.class, args);
	}

}
