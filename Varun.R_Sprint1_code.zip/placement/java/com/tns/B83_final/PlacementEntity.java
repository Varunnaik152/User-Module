package com.tns.B83_final;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import jakarta.persistence.Entity;


@Entity
@Table(name="Placement")
public class PlacementEntity { 
	
	private Integer id;
	 private String name;
	 private String college;
	 private String qualification;
	 
	 public PlacementEntity()
	 {
	 }
	 public PlacementEntity(Integer id, String name, String college,String qualification)
	 
	 { 
	        this.id = id; 
	        this.name = name; 
	        this.college = college; 
	        this.qualification=qualification;
	    } 
	  
	 @Id 
	    //@GeneratedValue(strategy = GenerationType.IDENTITY) 
	    public Integer getid()  
	    { 
	        return id; 
	    } 
	 
	 public void setid(Integer id)  
	 { 
	  this.id = id; 
	 } 
	 
	 public String getname()  
	 { 
	  return name; 
	 } 
	 
	 public void setname(String name)  
	 { 
	  this.name = name; 
	 } 
	 
	 public String getcollege()  
	 { 
	  return college; 
	 } 
	 
	 public void setcollege(String college)  
	 { 
	  this.college = college; 
	 } 
	 public String getqualification()  
	 { 
	  return qualification; 
	 } 
	 
	 public void setqualification(String qualification)  
	 { 
	  this.qualification = qualification; 
	 } 
	 
	 @Override 
	 public String toString()  
	 { 
	 return " [id=" + id + ", Name=" + name + ", college=" + college + ", qualification="+qualification+"]";

}
}



