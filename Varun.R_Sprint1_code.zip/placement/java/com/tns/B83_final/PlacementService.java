package com.tns.B83_final;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
@Service
//@Transactional
public class PlacementService {
	@Autowired
	 private PlacementRepository repo;

	 public List<PlacementEntity> listAll()
	 {
	 return repo.findAll();
	 }

	 public void save(PlacementEntity placement)
	 {
	 repo.save(placement);
	 }

	 public PlacementEntity get(Integer id)
	 {
	 return repo.findById(id).get();
	 }

	 public void delete(Integer id)
	 {
	 repo.deleteById(id);
	 }

}
